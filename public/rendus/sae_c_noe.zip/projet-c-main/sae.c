#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h> /* Noe qui a implemente les durees*/

#define SIZE_TABLE 128

/* include file */
#include "functMenu.h"
#include "functClient.h"




struct Personne {
    char prenom[SIZE_TABLE];
    char nom[SIZE_TABLE];
    char adresse[SIZE_TABLE];
    char codepostal[6];
    char numero_tel[SIZE_TABLE];
    char mail[SIZE_TABLE];
    char profession[SIZE_TABLE];
};
typedef struct Personne Personne;  /*Thomas*/

void addUser(FILE * fichier){   /*No� et Thomas*/
    Personne personne;
    char line [sizeof(Personne) + 7];
    int i;

    printf("\nQuel est le prenom de la personne? " );
    fgets(personne.prenom, SIZE_TABLE, stdin);
    printf("\nQuel est le nom de la personne? " );
    fgets(personne.nom, SIZE_TABLE, stdin);
    printf("\nQuel est l'adresse de la personne? " );
    fgets(personne.adresse, SIZE_TABLE, stdin);
    printf("\nQuel est le code postal de la personne? " );
    fgets(personne.codepostal, 6, stdin);
    printf("\nQuel est le numero de telephone de la personne? " );
    fgets(personne.numero_tel, SIZE_TABLE, stdin);
    printf("\nQuel est le mail de la personne? " );
    fgets(personne.mail, SIZE_TABLE, stdin);
    printf("\nQuel est la profession de la personne? " );
    fgets(personne.profession, SIZE_TABLE, stdin);

    verifRetour(personne.prenom);
    verifRetour(personne.nom);
    verifRetour(personne.adresse);
    verifRetour(personne.codepostal);
    verifRetour(personne.numero_tel);
    verifRetour(personne.mail);
    verifRetour(personne.profession);

    strcpy(line, personne.prenom);
    strcat(line, ",");
    strcat(line, personne.nom);
    strcat(line, ",");
    strcat(line, personne.adresse);
    strcat(line, ",");
    strcat(line, personne.codepostal);
    strcat(line, ",");
    strcat(line, personne.numero_tel);
    strcat(line, ",");
    strcat(line, personne.mail);
    strcat(line, ",");
    strcat(line, personne.profession);
    strcat(line, "\n");

    if(fputs(line, fichier) != 0){
        printf("Erreur");
    }
}



void verifRetour (char a [SIZE_TABLE]){ /*No�*/
    if (a[strlen(a)-1] =='\n'){
        a[strlen(a)-1] = '\0';
    }
}



void remplir(FILE * fichier,int* PTcompteurPers, Personne** PTTableau){   /*No�*/
    char c;
    int i,j,colonne;

    clock_t Chrono1, Chrono2;
    float Temps;
    Chrono1 = clock();

    Personne tempPers;
    Personne** PTTableauTemp;
    char chaine[128];

    while ((c = fgetc(fichier)) != EOF)
    {
        if (c == ','){
            switch (colonne){
                case 0:
                    strcpy(tempPers.prenom, chaine);
                    break;
                case 1:
                    strcpy(tempPers.nom, chaine);
                    break;
                case 2:
                    strcpy(tempPers.adresse, chaine);
                    break;
                case 3:
                    strcpy(tempPers.codepostal, chaine);
                    break;
                case 4:
                    strcpy(tempPers.numero_tel, chaine);
                    break;
                case 5:
                    strcpy(tempPers.mail, chaine);
                    break;
            }

            colonne++;
            i = 0;
            for (j=0;j<128;j++)
                chaine[j] = 0;

        }

        else if (c == '\n'){
            strcpy(tempPers.profession, chaine);
            (*PTTableau)[*PTcompteurPers] = tempPers;
            (*PTcompteurPers)++;
            if(((*PTcompteurPers)+1)%500 == 0){
                PTTableauTemp = (Personne *) realloc(*PTTableau, ((*PTcompteurPers)+1000)*sizeof(Personne));
                if (PTTableauTemp == NULL){
                    printf("Erreur de reallocation");
                    exit(-1);
                }
            *PTTableau = PTTableauTemp;
            }

            colonne = 0;
            i = 0;
            for (j=0;j<128;j++)
                chaine[j] = 0;
        }

        else{
            chaine[i] = c;
            i++;
        }
    }
    Chrono2 = clock();
    Temps = (float)(Chrono2-Chrono1)/CLOCKS_PER_SEC;
    printf("\nTemps de creation du Tableau : %f secondes \n",Temps);

}


void tri(struct Personne *tableau, int taille, int attribut) { /*Noe*/
    int i, j;
    char *k, *l;

    clock_t Chrono1, Chrono2;
    float Temps;
    Chrono1 = clock();

    struct Personne temp, *p = malloc(taille * sizeof(struct Personne));

    for (i = 0; i < taille - 1; i++) {
        for (j = 0; j < taille - i - 1; j++) {
            switch (attribut) {
                default:
                case 1:
                    k = tableau[j].prenom;
                    l = tableau[j + 1].prenom;
                    break;
                case 2:
                    k = tableau[j].nom;
                    l = tableau[j + 1].nom;
                    break;
                case 3:
                    k = tableau[j].adresse;
                    l = tableau[j + 1].adresse;
                    break;
                case 4:
                    k = tableau[j].codepostal;
                    l = tableau[j + 1].codepostal;
                    break;
                case 5:
                    k = tableau[j].numero_tel;
                    l = tableau[j + 1].numero_tel;
                    break;
                case 6:
                    k = tableau[j].mail;
                    l = tableau[j + 1].mail;
                    break;
                case 7:
                    k = tableau[j].profession;
                    l = tableau[j + 1].profession;
                    break;
            }
            if (strcmp(k, l) > 0) {
                temp = tableau[j];
                tableau[j] = tableau[j + 1];
                tableau[j + 1] = temp;
            }
        }
    }
    Chrono2 = clock();
    Temps = (float)(Chrono2-Chrono1)/CLOCKS_PER_SEC;
    printf("Temps d'execution : %f secondes \n",Temps);
}

void modifier(Personne* table, int taille_tab) /* Thomas */
{
    struct Personne p;
    char nom[255],prenom[255],adresse[255],codepostal[255],numero_tel[255],mail[255],profession[255];
    int i;
    int ligne;
    int etat = 0;
    printf("Ligne :");
    scanf("%d", &ligne);
    if(ligne > taille_tab){

        printf("Ce client n'existe pas ");
    }else{
        printf("Vous voulez modifier |%-3s|%-3s|%-3s|%3s|%3s|%3s|%-3s|\n",
            table[ligne].prenom,
            table[ligne].nom,
            table[ligne].adresse,
            table[ligne].codepostal,
            table[ligne].numero_tel,
            table[ligne].mail,
            table[ligne].profession

        );
        printf("\n selectionner| '1' pour Oui ou '0' pour Non :");
        scanf("%d", &etat);
        if(etat = 1) {
            printf("\n" );
            printf("Quel est le prenom de la personne : " );
            fgets(prenom, SIZE_TABLE, stdin);
            printf("Quel est le nom de la personne : " );
            fgets(nom, SIZE_TABLE, stdin);
            printf("Quel est l'adresse de la personne : " );
            fgets(adresse, SIZE_TABLE, stdin);
            printf("Quel est le code postal de la personne : " );
            fgets(codepostal, 6, stdin);
            printf("Quel est le numero de telephone de la personne :  " );
            fgets(numero_tel, SIZE_TABLE, stdin);
            printf("Quel est le mail de la personne : " );
            fgets(mail, SIZE_TABLE, stdin);
            printf("Quel est la profession de la personne : " );
            fgets(profession, SIZE_TABLE, stdin);

            /* A finir
            *table[ligne].prenom = *prenom;
            *table[ligne].nom = *nom;
            *table[ligne].adresse = *adresse;
            *table[ligne].codepostal = *codepostal;
            *table[ligne].numero_tel = *numero_tel;
            *table[ligne].mail = *mail;
            *table[ligne].profession = *profession;*/


            printf("modification reussi !");
        } else{
            printf("erreur retaper la commande 'supprimer'");
            }
    }



}


void supprimer(Personne* table, int taille_tab) /* Thomas */
{
    struct Personne p;
    int i;
    int etat = 0;
    int ligne;
    printf("Ligne :");
    scanf("%d", &ligne);

    if(ligne > taille_tab){
        printf("Ce client n'existe pas ");
    }

    else{
        printf("Vous voulez supprimer : [%s %s] ", table[ligne].prenom, table[ligne].nom);
        printf("\n Selectionnez | '1' pour Oui ou '0' pour Non :");
        scanf("%d", &etat);

        clock_t Chrono1, Chrono2;
        float Temps;
        Chrono1 = clock();

        if(etat = 1) {
            *table[ligne].prenom = NULL;
            *table[ligne].nom = NULL;
            *table[ligne].adresse = NULL;
            *table[ligne].codepostal = NULL;
            *table[ligne].numero_tel = NULL;
            *table[ligne].mail = NULL;
            *table[ligne].profession = NULL;
            printf("Supression reussi\n");
        } else if(etat = 0){
            printf("Supression annule\n");
        } else{
            printf("ERREUR retaper la commande 'supprimer'");
            }

        Chrono2 = clock();
        Temps = (float)(Chrono2-Chrono1)/CLOCKS_PER_SEC;
        printf("Temps d'execution : %f secondes \n",Temps);

    }



}


void afficher(Personne* table, int taille_tab) { /*Thomas*/
    int i;
    struct Personne p;
    clock_t Chrono1, Chrono2;
    float Temps;
    Chrono1 = clock();
    for (i=0; i < taille_tab; i++) {
        p = table[i];
        printf("ligne: %-7d|%-20s|%-25s|%-23s|%6s|%14s|%-50s|%-18s|\n",
            i,
            table[i].prenom,
            table[i].nom,
            table[i].adresse,
            table[i].codepostal,
            table[i].numero_tel,
            table[i].mail,
            table[i].profession

        );
    }
    Chrono2 = clock();
    Temps = (float)(Chrono2-Chrono1)/CLOCKS_PER_SEC;
    printf("Temps d'execution : %f secondes \n",Temps);
    welcome();

}

void commandeMenu(struct Personne *Tableau, int taille){

    int b;
    char commandes[255];
    int statmenu = 0;
    int compteurPers = 0;

    welcome();

    while(statmenu == 0){
        printf(" \nEntrez votre choix : " );
        fgets(commandes, 255, stdin);
        if(strcmp(commandes, "aide\n") == 0) helpmenu();
        if(strcmp(commandes, "sortir\n") == 0) statmenu = -1;
        if(strcmp(commandes, "afficher\n") == 0) afficher(Tableau, taille);
        if(strcmp(commandes, "supprimer\n") == 0) supprimer(Tableau, taille);
        if(strcmp(commandes, "modifier\n") == 0) modifier(Tableau, taille);
        if(strcmp(commandes, "trier\n") == 0){
            printf("Que voulez-vous trier ?\nTapez 1 pour les prenoms,\nTapez 2 pour les noms,\nTapez 3 pour les adresses,\nTapez 4 pour les codes postaux,\nTapez 5 pour les numeros de telephone,\nTapez 6 pour les mails,\nTapez 7 pour les professions,\n");
            scanf("%d", &b);
            tri(Tableau, taille, b);

        }

    }


}






int main(){ /*Thomas et Noe*/
    char nomFichier[255];
    int c,b;
    int a = 0;
    Personne* Tableau = calloc(500,sizeof(Personne));
    int compteurPers = 0;

    char tmp[SIZE_TABLE];
    int i;


    printf("########   BIENVENUE   ########  \n ");
    printf("\n Entrez le nom du fichier: ");
    fgets(nomFichier, 255, stdin);

    verifRetour(nomFichier);


    FILE* fichier = NULL;
    fichier = fopen(nomFichier, "r+");

    if (fichier != NULL)
    {
        remplir(fichier, &compteurPers, &Tableau);


        commandeMenu(Tableau, compteurPers);




        while ((c = fgetc(fichier)) != EOF) {

        }

    }

    else
    {
        // return error;
        printf("Impossible d'ouvrir le fichier ' %s '", nomFichier);
    }

    return 0;

}
