#ifndef _FUNCTMENU_H
#define _FUNCTMENU_H
#endif



void welcome(){
    printf(" \n ");
    printf("\n########   Menu   ########  \n ");
    printf("\n  'aide'    | Ouvrir le menu d'aide.\n ");
    printf(" 'afficher' | afficher la liste des clients\n ");

    /* gestion client */
    printf("\n - Gestion client : \n");

    printf(" \n  'ajouter'   | Ajouter un client\n ");
    printf(" 'supprimer' | Supprimer un client\n ");
    printf(" 'modifier'   | Modifier un client\n ");
    printf(" 'trier' | Trier la liste des clients\n ");


    /* other option */
     printf("\n - Options : \n");
    printf(" \n  'sortir' | sortir du menu \n ");
    printf("____________________\n ");

}

int helpmenu(){
    printf("\n #  -- aide --   #\n ");
    printf(" 'trier' | Trier la liste des clients dans l'ordre alphabethique\n ");
    printf(" 'ajouter' | Ajouter un client ex: Pierre Jack 08474  \n");
    printf(" 'sortir'  | Fermer le programme  \n");
    printf(" 'afficher' | afficher la liste des client\n ");
}


