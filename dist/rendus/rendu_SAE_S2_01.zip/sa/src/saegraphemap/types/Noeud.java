/*
 * Copyright (C) 2022 IUT
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package saegraphemap.types;

import java.util.ArrayList;

/**
 * Cette classe représente le type le modèle d'un Noeud après avoir transformé le csv en noeuds et liens
 * @author Noé CHOUTEAU
 * @version 1.0
 */
public class Noeud {
    
    
    
// <editor-fold defaultstate="collapsed" desc="    ATTRIBUTS">
    /**
     * Correspond au type de noeud, soit "V" pour ville, "R" pour restaurant et "L" pour centre de loisirs
     */
    private String typeNoeud;
    
    /**
     * Correspond au nom du noeud
     */
    private String nomNoeud;
    
    /**
     * Correspond à l'ensemble des liens du noeud
     */
    private ArrayList<Lien> liens;
    
     /**
     * Correspond à la coordonée X du noeud dans la représentation graphique
     */
    private int coordX;
    
     /**
     * Correspond à la coordonée Y du noeud dans la représentation graphique
     */
    private int coordY;
    
     /**
     * Détermine si le noeud est visible ou non
     */
    private boolean noeudVisible;
// </editor-fold>
    
    
    
// <editor-fold defaultstate="collapsed" desc="    CONSTRUCTOR">
    /**
     * Crée un noeud que l'on pourra afficher et/ou modifier
     * @param typeNoeud  Correspond au type de noeud, soit "V" pour ville, "R" pour restaurant et "L" pour centre de loisirs
     * @param nomNoeud Correspond au nom du noeud
     * @param liens Correspond à l'ensemble des liens du noeud
     */
    public Noeud(String typeNoeud, String nomNoeud, ArrayList<Lien> liens) {
        this.typeNoeud = typeNoeud;
        this.nomNoeud = nomNoeud;
        this.liens = liens;
    };
// </editor-fold>
    
    
    
// <editor-fold defaultstate="collapsed" desc="    METHODES PUBLICS">
    /**
     * Renvoie le type du noeud sélectionné
     * @return Retourne le type du noeud sélectionné
     */
    public String getTypeNoeud() {
        return typeNoeud;
    }

    /**
     * Renvoie le nom du noeud sélectionné
     * @return Retourne le nom du noeud sélectionné
     */
    public String getNomNoeud() {
        return nomNoeud;
    }

    /**
     * Renvoie la liste des liens du noeud sélectionné
     * @return Retourne la liste des liens du noeud sélectionné
     */
    public ArrayList<Lien> getLiens() {
        return liens;
    }

    /**
     * Renvoie la coordonée X du noeud sélectionné
     * @return Retourne la coordonée X du noeud sélectionné
     */
    public int getCoordX() {
        return coordX;
    }

    /**
     * Renvoie la coordonée Y du noeud sélectionné
     * @return Retourne la coordonée Y du noeud sélectionné
     */
    public int getCoordY() {
        return coordY;
    }

    /**
     * Renvoie  la valeur du boléen définissant la visibilité du noeud (true = visible, false = non visible)
     * @return Retourne la valeur du boléen définissant la visibilité du noeud (true = visible, false = non visible)
     */
     public boolean isNoeudVisible() {
        return noeudVisible;
    }
    
    /**
     * Modifie le type du noeud choisi
     * @param typeNoeud Correspond au nouveau type
     */
    public void setTypeNoeud(String typeNoeud) {
        this.typeNoeud = typeNoeud;
    }
    
    /**
     * Modifie le nom du noeud choisi
     * @param nomNoeud Correspond au nouveau nom
     */
    public void setNomNoeud(String nomNoeud) {
        this.nomNoeud = nomNoeud;
    }
    
    /**
     * Modifie la coordonée X du noeud choisi
     * @param coordX Correspond à la nouvelle coordonnée X
     */
    public void setCoordX(int coordX) {
        this.coordX = coordX;
    }
    
    /**
     * Modifie la coordonée Y du noeud choisi
     * @param coordY Correspond à la nouvelle coordonnée Y
     */
    public void setCoordY(int coordY) {
        this.coordY = coordY;
    }
    
    /**
     * Modifie la valeur du boléen définissant la visibilité du noeud (true = visible, false = non visible)
     * @param noeudVisible Correspond à la nouvelle valeur du booléen
     */
    public void setNoeudVisible(boolean noeudVisible) {
        this.noeudVisible = noeudVisible;
    }
    
    /**
     * Ajoute un lien dans la liste des liens du noeud
     * @param lien Correspond au lien à ajouter
     */
    public void addLiens(Lien lien) {
        this.liens.add(lien);
    }
    
    /**
     * Renvoie les informations les plus importantes pour pouvoir les afficher plus rapidement (juste besoin d'appeler la méthode)
     * @return Retourne le type et le nom du noeud séparés d'une virgule
     */
    public String afficheNoeud(){
        return(this.getTypeNoeud() + ", " + this.getNomNoeud());
    }
    
    /**
     * Calcule la distance entre le noeud sélectionné et un noeud passé en paramètre
     * @param noeud Correspond au noeud vers lequel nous souhaitons calculer la distance
     */
    public int distance(Noeud noeud){
        return (int) Math.sqrt(Math.pow(noeud.getCoordX() - this.getCoordX(),2) + Math.pow(noeud.getCoordY() - this.getCoordY(),2));
    }
// </editor-fold>
    
    
    
}
