/*
 * Copyright (C) 2022 IUT
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package saegraphemap;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JPanel;
import saegraphemap.types.Lien;
import saegraphemap.types.Noeud;

/**
 * Cette classe représente l'édition graphique et toute son interface
 * @author Noé CHOUTEAU
 */

public class dessinGraphe extends JPanel { 
    
    // <editor-fold defaultstate="collapsed" desc="    ATTRIBUTS">
    /**
     * Correspond  à la couleur de base attribuée aux centres de loisirs
     */
    public static final Color JAUNE = new Color(255,210,51,255);
    
    /**
     * Correspond  à la couleur de base attribuée aux villes
     */
    public static final Color VIOLET = new Color(217,155,255,255);
    
    /**
     * Correspond  à la couleur de base attribuée aux resraurants
     */
    public static final Color BLEU = new Color(133,182,255,255);
    
    /**
     * Correspond  à la couleur de base attribuée aux nationales
     */
    public static final Color VERT = new Color(78,203,113,255);
    
    /**
     * Correspond  à la couleur de base attribuée aux autoroutes
     */
    public static final Color ROSE = new Color(255,151,144,255);
    
    /**
     * Correspond  à la couleur de base attribuée aux départementales
     */
    public static final Color GRIS = new Color(196,196,196,255);
    
    /**
     * Correspond au booléen nous informant sur l'attribution de coordonnées aux noeuds
     */
    private boolean noeudsDejaPlaces = false;
    
    /**
     * Correspond au booléen nous informant sur la visibilité des noeuds
     */
    private static boolean noeudsVisibles = false;
    
    /**
     * Correspond au booléen nous informant sur l'importation des liens
     */
    private boolean liensImportes = false;
    
    /**
     * Correspond à la liste de noeuds issue du csv
     */
    private ArrayList<Noeud> listeNoeuds = new ArrayList<>();
    
    /**
     * Correspond à la liste de liens issue du csv
     */
    
    private ArrayList<Lien> listeLiens = new ArrayList<>();
     // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="    METHODES PUBLICS">
    /**
     * Ce qu'il va se passer quand va dessiner sur panel
     * @param g L'objet Graphics que l'on va utiliser
     */
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        
        //On ajoute de l'antialiasing pour l'esthétique
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        
        //Si les noeuds ne sont pas placés ouqu'ils sont visibles et que la liste n'est pas vide, alors on les redessine
        if((noeudsDejaPlaces == false || noeudsVisibles == true) && !listeNoeuds.isEmpty()){
            for(Noeud noeud:listeNoeuds){

                  noeud.setNoeudVisible(false);                
                  FontMetrics fm = g.getFontMetrics();
                  double texteEpaisseur = fm.getStringBounds(noeud.afficheNoeud(),g).getWidth();
                  int texteEpaisseurInt = (int) (texteEpaisseur);
                  
                //Si le type de noeud est une ville et que la case ville est cochée, alors on peut dessiner le noeud
                if(noeud.getTypeNoeud().equals("V") && SaeGRAPHEMAP.villeChecked() == true){
                    g.setColor(SaeGRAPHEMAP.getVilleColor().getBackground());
                    g.fillRoundRect(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50, 20,20);
                    
                    //Le noeud en question esy donc visible
                    noeud.setNoeudVisible(true);

                    //Si le noeud correspond à celui sélectionné par le click gauche, alros on ajoute une bordure noire
                    if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect().getNomNoeud())){
                        g.setColor(Color.black);
                        g.drawRoundRect(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50, 20,20);
                    }
                    
                    //Si c'est par le click droit, alors on ajoute une bordure rouge
                    else if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect2().getNomNoeud())){
                        g.setColor(Color.red);
                        g.drawRoundRect(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50, 20,20);
                    }
                    
                    g.setColor(Color.black);
                    g.drawString(noeud.afficheNoeud(), ( noeud.getCoordX() - texteEpaisseurInt /2), (int) (noeud.getCoordY() + fm.getMaxAscent()/2));
                }
                
                //Si le type de noeud est un restaurant et que la case restaurant est cochée, alors on  recommence aves les coulerus et formesa ttribuées pour les restaurants
                else if(noeud.getTypeNoeud().equals("R") && SaeGRAPHEMAP.restauChecked()== true){
                    g.setColor(SaeGRAPHEMAP.getRestauColor().getBackground());
                    g.fillOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    noeud.setNoeudVisible(true);
                    
                    if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect().getNomNoeud())){
                        g.setColor(Color.black);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }
                    
                    else if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect2().getNomNoeud())){
                        g.setColor(Color.red);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }

                    g.setColor(Color.black);
                    g.drawString(noeud.afficheNoeud(), ( noeud.getCoordX() - texteEpaisseurInt /2), (int) (noeud.getCoordY() + fm.getMaxAscent()/2));
                }

                 //Encore une fois, pareil pour les centres de loisirs
                else if(noeud.getTypeNoeud().equals("L") && SaeGRAPHEMAP.loisirChecked()== true){
                    g.setColor(SaeGRAPHEMAP.getLoisirColor().getBackground());
                    g.fillOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    noeud.setNoeudVisible(true);
                    
                    if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect().getNomNoeud())){
                        g.setColor(Color.black);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }
                    
                    else if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect2().getNomNoeud())){
                        g.setColor(Color.red);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }
                    
                    g.setColor(Color.black);
                    g.drawString(noeud.afficheNoeud(), ( noeud.getCoordX() - texteEpaisseurInt /2), (int) (noeud.getCoordY() + fm.getMaxAscent()/2));
                }
             }
            
            //Tous les noeuds sont désormais placés
           noeudsDejaPlaces = true;
          }
       
      if(liensImportes == true){
          //pour chaque lien de la liste
            for(Lien lien:listeLiens){
                g.setColor(choixColorLien(lien));
                
                //si le type de lien est coché et que les deux noeuds du liens sont visibles, alors on peut le dessiner
                if(lien.getTypeLien().equals(" A") && SaeGRAPHEMAP.autoChecked() == true){
                    if(lien.getNoeudParent().isNoeudVisible() == true && lien.getNoeudEnfant().isNoeudVisible() == true){
                        g.drawLine(lien.getNoeudParent().getCoordX(), lien.getNoeudParent().getCoordY(), 
                                  lien.getNoeudEnfant().getCoordX(), lien.getNoeudEnfant().getCoordY());
                         g.drawString(lien.getTypeLien() +", " + lien.getTailleLien(),(lien.getNoeudParent().getCoordX() + lien.getNoeudEnfant().getCoordX()) /2,   (lien.getNoeudParent().getCoordY() +lien.getNoeudEnfant().getCoordY())/2 );
                    }
                }
                
                if(lien.getTypeLien().equals(" N") && SaeGRAPHEMAP.natioChecked() == true){
                    if(lien.getNoeudParent().isNoeudVisible() == true && lien.getNoeudEnfant().isNoeudVisible() == true){
                        g.drawLine(lien.getNoeudParent().getCoordX(), lien.getNoeudParent().getCoordY(), 
                                  lien.getNoeudEnfant().getCoordX(), lien.getNoeudEnfant().getCoordY());
                         g.drawString(lien.getTypeLien() +", " + lien.getTailleLien(),(lien.getNoeudParent().getCoordX() + lien.getNoeudEnfant().getCoordX()) /2,   (lien.getNoeudParent().getCoordY() +lien.getNoeudEnfant().getCoordY())/2 );
                    }
                }
                
                if(lien.getTypeLien().equals(" D") && SaeGRAPHEMAP.deparChecked() == true){
                    if(lien.getNoeudParent().isNoeudVisible() == true && lien.getNoeudEnfant().isNoeudVisible() == true){
                        g.drawLine(lien.getNoeudParent().getCoordX(), lien.getNoeudParent().getCoordY(), 
                                  lien.getNoeudEnfant().getCoordX(), lien.getNoeudEnfant().getCoordY());
                         g.drawString(lien.getTypeLien() +", " + lien.getTailleLien(),(lien.getNoeudParent().getCoordX() + lien.getNoeudEnfant().getCoordX()) /2,   (lien.getNoeudParent().getCoordY() +lien.getNoeudEnfant().getCoordY())/2 );
                    }
                }
            }

            //il faut également dessiner les noeuds, donc on recommence
          if((noeudsDejaPlaces == false || noeudsVisibles == true) && !listeNoeuds.isEmpty()){
            for(Noeud noeud:listeNoeuds){
                  noeud.setNoeudVisible(false);                
                  FontMetrics fm = g.getFontMetrics();
                  double texteEpaisseur = fm.getStringBounds(noeud.afficheNoeud(),g).getWidth();
                  int texteEpaisseurInt = (int) (texteEpaisseur);
                  

                if(noeud.getTypeNoeud().equals("V") && SaeGRAPHEMAP.villeChecked() == true){
                    g.setColor(SaeGRAPHEMAP.getVilleColor().getBackground());
                    g.fillRoundRect(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50, 20,20);
                    noeud.setNoeudVisible(true);

                    if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect().getNomNoeud())){
                        g.setColor(Color.black);
                        g.drawRoundRect(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50, 20,20);
                    }
                    
                    else if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect2().getNomNoeud())){
                        g.setColor(Color.red);
                        g.drawRoundRect(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50, 20,20);
                    }
                    
                    g.setColor(Color.black);
                    g.drawString(noeud.afficheNoeud(), ( noeud.getCoordX() - texteEpaisseurInt /2), (int) (noeud.getCoordY() + fm.getMaxAscent()/2));
                }

                else if(noeud.getTypeNoeud().equals("R") && SaeGRAPHEMAP.restauChecked()== true){
                    g.setColor(SaeGRAPHEMAP.getRestauColor().getBackground());
                    g.fillOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    noeud.setNoeudVisible(true);
                    
                    if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect().getNomNoeud())){
                        g.setColor(Color.black);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }
                    
                    else if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect2().getNomNoeud())){
                        g.setColor(Color.red);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }

                    g.setColor(Color.black);
                    g.drawString(noeud.afficheNoeud(), ( noeud.getCoordX() - texteEpaisseurInt /2), (int) (noeud.getCoordY() + fm.getMaxAscent()/2));
                }

                else if(noeud.getTypeNoeud().equals("L") && SaeGRAPHEMAP.loisirChecked()== true){
                    g.setColor(SaeGRAPHEMAP.getLoisirColor().getBackground());
                    g.fillOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    noeud.setNoeudVisible(true);
                    
                    if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect().getNomNoeud())){
                        g.setColor(Color.black);
                        g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }
                    
                    else if(noeud.getNomNoeud().equals(SaeGRAPHEMAP.getNoeudSelect2().getNomNoeud())){
                        g.setColor(Color.red);
                       g.drawOval(noeud.getCoordX() - (texteEpaisseurInt +20)/2 ,noeud.getCoordY() - 50/2,texteEpaisseurInt +20,50);
                    }
                    
                    g.setColor(Color.black);
                    g.drawString(noeud.afficheNoeud(), ( noeud.getCoordX() - texteEpaisseurInt /2), (int) (noeud.getCoordY() + fm.getMaxAscent()/2));
                }
             }

      }}
     }
    
    /**
     * Remet à zéro l'écran et les coordonnées attribuées aux noeuds
     */
    public void effacer(){
        noeudsDejaPlaces = false;
        noeudsVisibles = false;
        liensImportes = false;
        listeLiens = new ArrayList<>();
        listeNoeuds = new ArrayList<>();
        this.repaint();
    }
    
    /**
     * Définit les coordonnées de chaque noeuds de manière aléatoire
     * @param noeuds Correspond au noeud dont on veut modifier les coordonnées
     */
    public void defCoordNoeuds(ArrayList<Noeud> noeuds){
        
        //Pour chaque noeuds de la liste, on attribue des coordonnées aléatoires
        for(int i = 0; i<noeuds.size();i++){
            Random random = new Random();
            int x = random.nextInt(this.getWidth());
            int y = random.nextInt(this.getHeight());
            
            //Les coordonnées doivent être comprises dans l'écran, mais pas sur les bordures (donc il faut soustraire)
            while((x  > this.getWidth() -70 || y > this.getHeight() -50) || (x  < 70 || y < 50)){
                 x = random.nextInt(this.getWidth());
                 y = random.nextInt(this.getHeight());
            }
            
            //On attribue les coordonnées à un noeud temporaire
            Noeud tempNoeud = new Noeud("","",null);
            tempNoeud.setCoordX(x);
            tempNoeud.setCoordY(y);
            
            //Tant que les coordonnées de ce noeud temporaire ne sont pas validées, on répète le processus exécuté plus haut
            while(validePos(tempNoeud) != true){
                random = new Random();
                x = random.nextInt(this.getWidth());
                y = random.nextInt(this.getHeight());
                while((x  > this.getWidth() -70 || y > this.getHeight() -50) || (x  < 70 || y < 50)){
                     x = random.nextInt(this.getWidth());
                     y = random.nextInt(this.getHeight());
            }
                tempNoeud.setCoordX(x);
                tempNoeud.setCoordY(y);
            }
            
            //Une fois les coordonnées bien validées, on peut les attribuer à notre point
            noeuds.get(i).setCoordX(x);
            noeuds.get(i).setCoordY(y);
            noeuds.get(i).setNoeudVisible(true);

            //On ajoute le noeud à la liste
            listeNoeuds.add(noeuds.get(i));
        }
    }
    
    /**
     * Permet de notifier que les noeuds sont désormais visibles (les ajouter à l'écran)
     */
    public void addNoeuds(){
          noeudsVisibles = true;
          this.repaint();
    }
    
    /**
     * Permet de cacher les noeuds si visibles et de les rendre visible si cachés
     */
    public void cacheNoeuds(){
        System.out.println(noeudsDejaPlaces);
        if(noeudsVisibles == false){
            noeudsVisibles = true;
                    this.repaint();
        }
        else {
                noeudsVisibles = false;
                this.repaint();
        }
    }
    
    /**
     * Permet d'ajouter les liens et de placer les noeuds si ce n'est pas déjà le cas
     * @param liens Les liens à ajouter dans la représentation graphiqe
     * @param noeuds Les noeuds à ajouter dans la représentation graphiqe
     */
    public void addLiens(ArrayList<Lien> liens, ArrayList<Noeud> noeuds){
        liensImportes = true;
        noeudsDejaPlaces = true;

        
        if(listeNoeuds.isEmpty()){
              this.defCoordNoeuds(noeuds);
          }
        
        for(int i=0; i<liens.size();i++){
              listeLiens.add(liens.get(i));
        }
        this.repaint();
    }
    
    /**
     *  Permet de cacher les liens et de préciser que les noeuds sont toujours placés
     */
    public void cacheLiens(){
        liensImportes = false;
        if(noeudsDejaPlaces == false){
           noeudsDejaPlaces = true;
        }
        this.repaint();
    }
    
    /**
     * Permet de choisir la couleur du lien en fonction du type et de la couleur du panel attribué
     * @param lien Correspond au lien à modifier
     * @return La couleur à attribuer en fonction du type
     */
    public Color choixColorLien(Lien lien){
        switch (lien.getTypeLien()) {
            case " A":
                return SaeGRAPHEMAP.getAutoColor().getBackground();
            case " N":
                return SaeGRAPHEMAP.getNatioColor().getBackground();
            default:
                return SaeGRAPHEMAP.getDeparColor().getBackground();
        }
    }
    
    /**
     * Permet de vérifier que les coordonnées attribuées au point sont valides (donc que les cercles ne se touchent pas)
     * @param noeud Correspond au noeud dont on doit vérifier les coordonnées
     * @return Si oui ou non la position est bonne
     */
    public boolean validePos(Noeud noeud){
            for(Noeud noeudCourant:listeNoeuds){
                    if(noeudCourant.distance(noeud) < 125){
                        return false;
                    }
            }
            return true;
        }
    
    /**
     * Renvoie le boolean informant sur l'attribution de coordonnées aux noeuds
     * @return Retourne le boolean informant sur l'attribution de coordonnées aux noeuds
     */
    public boolean getNoeudsDejaPlaces(){
        return noeudsDejaPlaces;
    }
    
    /**
     * Renvoie le boolean informant sur la visibilité des noeuds
     * @return Retourne le boolean informant sur la visibilité des noeuds
     */
    public static boolean getNoeudsVisibles(){
        return noeudsVisibles;
    }
    
    /**
     * Renvoie le booléen nous informant sur l'importation des liens
     * @return Retourne le booléen nous informant sur l'importation des liens
     */
    public boolean getLiensImportes(){
        return liensImportes;
    }
    
    /**
     * Renvoie la liste des noeuds que l'on utilise
     * @return Retourn la liste des noeuds que l'on utilise
     */
    public ArrayList<Noeud> getListeNoeuds(){
        return listeNoeuds;
    }
    // </editor-fold>
    
    
}
