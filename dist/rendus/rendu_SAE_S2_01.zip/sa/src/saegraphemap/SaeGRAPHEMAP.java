/*
 * Copyright (C) 2022 IUT
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package saegraphemap;

import java.awt.Color;
import java.awt.Image;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import static saegraphemap.dessinGraphe.BLEU;
import static saegraphemap.dessinGraphe.GRIS;
import static saegraphemap.dessinGraphe.JAUNE;
import static saegraphemap.dessinGraphe.ROSE;
import static saegraphemap.dessinGraphe.VERT;
import static saegraphemap.dessinGraphe.VIOLET;
import saegraphemap.types.Lien;
import saegraphemap.types.Noeud;

/**
 * Cette classe représente la fenêtre principale du projet
 * @author Noé CHOUTEAU
 */
public class SaeGRAPHEMAP extends javax.swing.JFrame {
    
    
    
// <editor-fold defaultstate="collapsed" desc="    ATTRIBUTS">
    /**
     * Correspond au "parser"/analyseur qui tranformera le csv en liens et noeuds
     */
   private  csvTraducteur docCsv = new csvTraducteur();
    
    /**
     * Correspond à la couleur choisie par l'utilisateur en fonction des différents panels
     */
    private Color colorChoosen;
    
    /**
     * Correspond à un instance de colorChooser pour pouvoir changer les couleurs des panels
     */
    private JColorChooser colorPick = new JColorChooser();
    
     /**
     * Correspond au booléen décrivant si oui ou non les éléments ont étés changés de place
     */
    private boolean modif = false;
    
     /**
     * Correspond à l'instance de selectionNoeuds permettant de sélectionner un noeud en cliquant
     */
    private selectionNoeuds select;
    
     /**
     * Correspond au noeud sélectionné
     */
    private static Noeud noeudSelect = new Noeud("","",new ArrayList<>());
    
     /**
     * Correspond au deuxième noeud sélectionné
     */
    private static Noeud noeudSelect2 = new Noeud("","",new ArrayList<>());
     // </editor-fold>
    
    
    
 // <editor-fold defaultstate="collapsed" desc="    CONSTRUCTOR">
        /**
     * Crée la fenêtre principale du projet et instancier la couleur de nos éléments en fonction de celles de base
     */
    public SaeGRAPHEMAP() throws FileNotFoundException {
        ImageIcon img = new ImageIcon(".\\assets\\logo.png");
        this.setIconImage(img.getImage());
        initComponents();
        villeColor.setBackground(VIOLET);
        restauColor.setBackground(BLEU);
        loisirColor.setBackground(JAUNE);
        autoColor.setBackground(ROSE);
        deparColor.setBackground(VERT);
        natioColor.setBackground(GRIS);
    }
    // </editor-fold>
    

    
// <editor-fold defaultstate="collapsed" desc="    METHODES PUBLICS">
   /**
     * Renvoie si, oui ou non, villeCheck est cochée (par défaut: oui)
     * @return Retourne le booléen correspond à si, oui ou non, villeCheck est cochée (par défaut: oui)
     */
       public static boolean villeChecked(){
        return villeCheck.isSelected();
    }
    
   /**
     * Renvoie si, oui ou non, restauCheck est cochée (par défaut: oui)
     * @return Retourne le booléen correspond à si, oui ou non, restauCheck est cochée (par défaut: oui)
     */
    public static boolean restauChecked(){
        return restauCheck.isSelected();
    }
    
   /**
     * Renvoie si, oui ou non, loisirCheck est cochée (par défaut: oui)
     * @return Retourne le booléen correspond à si, oui ou non, loisirCheck est cochée (par défaut: oui)
     */
    public static boolean loisirChecked(){
        return loisirCheck.isSelected();
    }
    
   /**
     * Renvoie si, oui ou non, autoCheck est cochée (par défaut: oui)
     * @return Retourne le booléen correspond à si, oui ou non, autoCheck est cochée (par défaut: oui)
     */
    public static boolean autoChecked(){
        return autoCheck.isSelected();
    }
    
   /**
     * Renvoie si, oui ou non, natioCheck est cochée (par défaut: oui)
     * @return Retourne le booléen correspond à si, oui ou non, natioCheck est cochée (par défaut: oui)
     */
    public static boolean natioChecked(){
        return natioCheck.isSelected();
    }
    
   /**
     * Renvoie si, oui ou non, deparCheck est cochée (par défaut: oui)
     * @return Retourne le booléen correspond à si, oui ou non, deparCheck est cochée (par défaut: oui)
     */
    public static boolean deparChecked(){
        return deparCheck.isSelected();
    }

    /**
     * Renvoie le panel villeColor et, donc, la valeur de ses attributs
     * @return Retourne le panel villeColor et, donc, la valeur de ses attributs
     */
    public static JPanel getVilleColor() {
        return villeColor;
    }
    
    /**
     * Renvoie le panel restauColor et, donc, la valeur de ses attributs
     * @return Retourne le panel restauColor et, donc, la valeur de ses attributs
     */
    public static JPanel getRestauColor() {
        return restauColor;
    }
    
    /**
     * Renvoie le panel loisirColor et, donc, la valeur de ses attributs
     * @return Retourne le panel loisirColor et, donc, la valeur de ses attributs
     */
    public static JPanel getLoisirColor() {
        return loisirColor;
    }
    
    /**
     * Renvoie le panel autoColor et, donc, la valeur de ses attributs
     * @return Retourne le panel autoColor et, donc, la valeur de ses attributs
     */
    public static JPanel getAutoColor() {
        return autoColor;
    }

    /**
     * Renvoie le panel natioColor et, donc, la valeur de ses attributs
     * @return Retourne le panel natioColor et, donc, la valeur de ses attributs
     */
    public static JPanel getNatioColor() {
        return deparColor;
    }
    
    /**
     * Renvoie le panel deparColor et, donc, la valeur de ses attributs
     * @return Retourne le panel deparColor et, donc, la valeur de ses attributs
     */
    public static JPanel getDeparColor() {
        return natioColor;
    }
    
    /**
     * Renvoie la page de dessin comportant tous les éléments graphiques
     * @return Retourne la page de dessin comportant tous les éléments graphiques
     */
    public static dessinGraphe getPageDessin(){
        return pageDessin;
    }
    
    /**
     * Renvoie le noeud sélectionné
     * @return Retourne le noeud sélectionné
     */
    public static Noeud getNoeudSelect(){
        return noeudSelect;
    }
    
    /**
     * Remplace la valeur du noeud anciennement sélectionné par le nouveau
     * @param noeud Le nouveau noeud à entrer
     */
    public static void setNoeudSelect(Noeud noeud){
        noeudSelect = noeud;
    }
    
    /**
     * Renvoie le deuxième noeud sélectionné
     * @return Retourne le deuxième noeud sélectionné
     */
    public static Noeud getNoeudSelect2(){
        return noeudSelect2;
    }
    
    /**
     * Remplace la valeur du deuxième noeud anciennement sélectionné par le nouveau
     * @param noeud Le nouveau noeud à entrer
     */
    public static void setNoeudSelect2(Noeud noeud){
        noeudSelect2 = noeud;
    }
    
    /**
     * Modifie la couleur du background d'un panel passé en paramètre tout en la sauvegardant dans colorChoosen
     * @param newColor Correspond à la nouvelle couleur choisie
     * @param  panel      Correspond au panel que l'on veut modifier
     */
    public void panelSetColor(Color newColor, JPanel panel) {
        if(newColor != null){
            this.colorChoosen = newColor;
            panel.setBackground(newColor);
            pageDessin.repaint();
        }
    }
    /**
     * Permet de savoir si les noeuds sont à 2-distance ou non.
     * @param noeud1 Correspond au premier noeud sélectionné
     * @param noeud2 Correspond au deuxième noeud sélectionné
     * @return 
     */
    public boolean calculDistanceNoeuds(Noeud noeud1, Noeud noeud2){
        Noeud noeudInter = new Noeud("","",new ArrayList<>());
        
         for(int i=0; i<noeud1.getLiens().size();i++){
             if(noeud1.getLiens().get(i).getNoeudParent().getNomNoeud().equals(noeud2.getNomNoeud()) || noeud1.getLiens().get(i).getNoeudEnfant().getNomNoeud().equals(noeud2.getNomNoeud())){
                 return false;
                  }
             
             if(noeud1.getLiens().get(i).getNoeudParent().getNomNoeud().equals(noeud1.getNomNoeud())){
                 noeudInter = noeud1.getLiens().get(i).getNoeudEnfant();
             }
             else if(noeud1.getLiens().get(i).getNoeudEnfant().getNomNoeud().equals(noeud1.getNomNoeud())){
                 noeudInter = noeud1.getLiens().get(i).getNoeudParent();
             }
             
             for(int j= 0; j<noeudInter.getLiens().size();j++){
                 if(noeudInter.getLiens().get(j).getNoeudParent().getNomNoeud().equals(noeud2.getNomNoeud()) || noeudInter.getLiens().get(j).getNoeudEnfant().getNomNoeud().equals(noeud2.getNomNoeud())){
                     return true;
                 }
             }
         }
        return false;
    }
    
    /**
     * Permet d'obtenir le nombre de villes, restaurants et centres de loisirs à 2-distance du noeud entré en paramètre
     * @param noeud Correspond au noeud dont on souhaite obtenir les informations
     * @return Une ArrayList contenant les trois valeurs désirées
     */
    public ArrayList<String> nbTypesDistance(Noeud noeud){
        Noeud noeudInter = new Noeud("","",new ArrayList<>());
        ArrayList<String> noeudTraite = new ArrayList<>();
        int nbVilles = 0;
        int nbRestau = 0;
        int nbLoisirs = 0;

        for(int i=0; i<noeud.getLiens().size();i++){
            
            if(noeud.getLiens().get(i).getNoeudParent().getNomNoeud().equals(noeud.getNomNoeud())){
                 noeudTraite.add(noeud.getLiens().get(i).getNoeudEnfant().getNomNoeud());
             }
             else if(noeud.getLiens().get(i).getNoeudEnfant().getNomNoeud().equals(noeud.getNomNoeud())){
                 noeudTraite.add(noeud.getLiens().get(i).getNoeudParent().getNomNoeud());
             }
        }
        
        for(int i=0; i<noeud.getLiens().size();i++){
            
            if(noeud.getLiens().get(i).getNoeudParent().getNomNoeud().equals(noeud.getNomNoeud())){
                 noeudInter = noeud.getLiens().get(i).getNoeudEnfant();
             }
             else if(noeud.getLiens().get(i).getNoeudEnfant().getNomNoeud().equals(noeud.getNomNoeud())){
                 noeudInter = noeud.getLiens().get(i).getNoeudParent();
             }
            
            for(int j= 0; j<noeudInter.getLiens().size();j++){
                
                if(noeudInter.getLiens().get(j).getNoeudParent().getNomNoeud().equals(noeudInter.getNomNoeud()) && 
                        !noeudInter.getLiens().get(j).getNoeudEnfant().getNomNoeud().equals(noeud.getNomNoeud()) &&
                        !noeudTraite.contains(noeudInter.getLiens().get(j).getNoeudEnfant().getNomNoeud())){
                 
                    noeudTraite.add(noeudInter.getLiens().get(j).getNoeudEnfant().getNomNoeud());
                    switch (noeudInter.getLiens().get(j).getNoeudEnfant().getTypeNoeud()) {
                        case "V":
                            nbVilles++;
                            break;
                        case "R":
                            nbRestau++;
                            break;
                        default:
                            nbLoisirs++;
                            break;
                    }
             }
             else if(noeudInter.getLiens().get(j).getNoeudEnfant().getNomNoeud().equals(noeudInter.getNomNoeud())&& 
                     !noeudInter.getLiens().get(j).getNoeudParent().getNomNoeud().equals(noeud.getNomNoeud()) &&
                     !noeudTraite.contains(noeudInter.getLiens().get(j).getNoeudParent().getNomNoeud())){
                 
                    noeudTraite.add(noeudInter.getLiens().get(j).getNoeudParent().getNomNoeud());
                 switch (noeudInter.getLiens().get(j).getNoeudParent().getTypeNoeud()) {
                        case "V":
                            nbVilles++;
                            break;
                        case "R":
                            nbRestau++;
                            break;
                        default:
                            nbLoisirs++;
                            break;
                    }
             }
            }
        }
            ArrayList<String> listeValeurs = new ArrayList<>();
            listeValeurs.add(Integer.toString(nbVilles));
            listeValeurs.add(Integer.toString(nbRestau));
            listeValeurs.add(Integer.toString(nbLoisirs));
        return listeValeurs;
    }
    // </editor-fold>
    
    
    
// <editor-fold defaultstate="collapsed" desc="    METHODES PRIVATES">
    /**
     * Cette methode est appelée par le constructeur pour initialiser la fenêtre
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        boutonReset = new javax.swing.JButton();
        noeudsPanel = new javax.swing.JPanel();
        boutonNoeuds = new javax.swing.JButton();
        restauCheck = new javax.swing.JCheckBox();
        loisirCheck = new javax.swing.JCheckBox();
        restauColor = new javax.swing.JPanel();
        villeColor = new javax.swing.JPanel();
        loisirColor = new javax.swing.JPanel();
        villeCheck = new javax.swing.JCheckBox();
        nbNoeudsCheck = new javax.swing.JCheckBox();
        listeNoeudsCheck = new javax.swing.JCheckBox();
        liensPanel = new javax.swing.JPanel();
        natioCheck = new javax.swing.JCheckBox();
        deparCheck = new javax.swing.JCheckBox();
        deparColor = new javax.swing.JPanel();
        autoColor = new javax.swing.JPanel();
        natioColor = new javax.swing.JPanel();
        autoCheck = new javax.swing.JCheckBox();
        boutonLiens = new javax.swing.JButton();
        nbLiensCheck = new javax.swing.JCheckBox();
        listeLiensCheck = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        noeudsTable = new javax.swing.JTable();
        noeudListeLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        liensTable = new javax.swing.JTable();
        lienListeLabel = new javax.swing.JLabel();
        selectionFichier = new javax.swing.JButton();
        noeudSelectLabel = new javax.swing.JLabel();
        lienSelectLabel = new javax.swing.JLabel();
        lienSelectCOMBOX = new javax.swing.JComboBox<>();
        villesVoisLabel = new javax.swing.JLabel();
        restauVoisLabel = new javax.swing.JLabel();
        loisirVoisLabel = new javax.swing.JLabel();
        lienDescLabel = new javax.swing.JLabel();
        lienDescLabel2 = new javax.swing.JLabel();
        lienDescLabel3 = new javax.swing.JLabel();
        distanceLabel = new javax.swing.JLabel();
        loisirVoisLabel2 = new javax.swing.JLabel();
        restauVoisLabel2 = new javax.swing.JLabel();
        villesVoisLabel2 = new javax.swing.JLabel();
        noeudSelect2Label = new javax.swing.JLabel();
        culturelleLabel = new javax.swing.JLabel();
        gastronomiqueLabel = new javax.swing.JLabel();
        ouverteLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        pageDessin = new saegraphemap.dessinGraphe();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Graphe-MAP");
        setMinimumSize(new java.awt.Dimension(1400, 1000));

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        boutonReset.setText("Changer la disposition");
        boutonReset.setEnabled(false);
        boutonReset.setFocusable(false);
        boutonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boutonResetActionPerformed(evt);
            }
        });

        noeudsPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Noeuds"));
        noeudsPanel.setEnabled(false);

        boutonNoeuds.setText("Afficher les noeuds");
        boutonNoeuds.setEnabled(false);
        boutonNoeuds.setFocusable(false);
        boutonNoeuds.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boutonNoeudsActionPerformed(evt);
            }
        });

        restauCheck.setSelected(true);
        restauCheck.setText("Restaurants");
        restauCheck.setEnabled(false);
        restauCheck.setFocusable(false);
        restauCheck.setPreferredSize(new java.awt.Dimension(85, 25));
        restauCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restauCheckActionPerformed(evt);
            }
        });

        loisirCheck.setSelected(true);
        loisirCheck.setText("Centres de loisirs");
        loisirCheck.setEnabled(false);
        loisirCheck.setFocusable(false);
        loisirCheck.setPreferredSize(new java.awt.Dimension(107, 25));
        loisirCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loisirCheckActionPerformed(evt);
            }
        });

        restauColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        restauColor.setPreferredSize(new java.awt.Dimension(25, 25));
        restauColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                restauColorMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout restauColorLayout = new javax.swing.GroupLayout(restauColor);
        restauColor.setLayout(restauColorLayout);
        restauColorLayout.setHorizontalGroup(
            restauColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        restauColorLayout.setVerticalGroup(
            restauColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        villeColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        villeColor.setMaximumSize(new java.awt.Dimension(25, 25));
        villeColor.setPreferredSize(new java.awt.Dimension(25, 25));
        villeColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                villeColorMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout villeColorLayout = new javax.swing.GroupLayout(villeColor);
        villeColor.setLayout(villeColorLayout);
        villeColorLayout.setHorizontalGroup(
            villeColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        villeColorLayout.setVerticalGroup(
            villeColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        loisirColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        loisirColor.setPreferredSize(new java.awt.Dimension(25, 25));
        loisirColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loisirColorMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout loisirColorLayout = new javax.swing.GroupLayout(loisirColor);
        loisirColor.setLayout(loisirColorLayout);
        loisirColorLayout.setHorizontalGroup(
            loisirColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        loisirColorLayout.setVerticalGroup(
            loisirColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        villeCheck.setSelected(true);
        villeCheck.setText("Villes");
        villeCheck.setEnabled(false);
        villeCheck.setFocusable(false);
        villeCheck.setPreferredSize(new java.awt.Dimension(49, 25));
        villeCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                villeCheckActionPerformed(evt);
            }
        });

        nbNoeudsCheck.setText("Nombre d'éléments");
        nbNoeudsCheck.setEnabled(false);
        nbNoeudsCheck.setFocusable(false);
        nbNoeudsCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nbNoeudsCheckActionPerformed(evt);
            }
        });

        listeNoeudsCheck.setText("Liste d'éléments");
        listeNoeudsCheck.setEnabled(false);
        listeNoeudsCheck.setFocusable(false);
        listeNoeudsCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listeNoeudsCheckActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout noeudsPanelLayout = new javax.swing.GroupLayout(noeudsPanel);
        noeudsPanel.setLayout(noeudsPanelLayout);
        noeudsPanelLayout.setHorizontalGroup(
            noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(noeudsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(noeudsPanelLayout.createSequentialGroup()
                        .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(villeCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(restauCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(loisirCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(noeudsPanelLayout.createSequentialGroup()
                                .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(restauColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(villeColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(loisirColor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(noeudsPanelLayout.createSequentialGroup()
                        .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(listeNoeudsCheck)
                            .addComponent(nbNoeudsCheck)
                            .addComponent(boutonNoeuds, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        noeudsPanelLayout.setVerticalGroup(
            noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(noeudsPanelLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(boutonNoeuds)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nbNoeudsCheck)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(listeNoeudsCheck)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(villeColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(villeCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(restauCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(restauColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(noeudsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(loisirCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loisirColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        liensPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Liens"));
        liensPanel.setEnabled(false);

        natioCheck.setSelected(true);
        natioCheck.setText("Nationales");
        natioCheck.setEnabled(false);
        natioCheck.setFocusable(false);
        natioCheck.setPreferredSize(new java.awt.Dimension(85, 25));
        natioCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                natioCheckActionPerformed(evt);
            }
        });

        deparCheck.setSelected(true);
        deparCheck.setText("Départementales");
        deparCheck.setEnabled(false);
        deparCheck.setFocusable(false);
        deparCheck.setPreferredSize(new java.awt.Dimension(107, 25));
        deparCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deparCheckActionPerformed(evt);
            }
        });

        deparColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        deparColor.setMinimumSize(new java.awt.Dimension(25, 25));
        deparColor.setPreferredSize(new java.awt.Dimension(25, 25));
        deparColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deparColorMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout deparColorLayout = new javax.swing.GroupLayout(deparColor);
        deparColor.setLayout(deparColorLayout);
        deparColorLayout.setHorizontalGroup(
            deparColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        deparColorLayout.setVerticalGroup(
            deparColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        autoColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        autoColor.setMaximumSize(new java.awt.Dimension(25, 25));
        autoColor.setPreferredSize(new java.awt.Dimension(25, 25));
        autoColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                autoColorMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout autoColorLayout = new javax.swing.GroupLayout(autoColor);
        autoColor.setLayout(autoColorLayout);
        autoColorLayout.setHorizontalGroup(
            autoColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        autoColorLayout.setVerticalGroup(
            autoColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        natioColor.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        natioColor.setPreferredSize(new java.awt.Dimension(25, 25));
        natioColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                natioColorMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout natioColorLayout = new javax.swing.GroupLayout(natioColor);
        natioColor.setLayout(natioColorLayout);
        natioColorLayout.setHorizontalGroup(
            natioColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        natioColorLayout.setVerticalGroup(
            natioColorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        autoCheck.setSelected(true);
        autoCheck.setText("Autoroutes");
        autoCheck.setEnabled(false);
        autoCheck.setFocusable(false);
        autoCheck.setPreferredSize(new java.awt.Dimension(49, 25));
        autoCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autoCheckActionPerformed(evt);
            }
        });

        boutonLiens.setText("Afficher les liens");
        boutonLiens.setEnabled(false);
        boutonLiens.setFocusable(false);
        boutonLiens.setPreferredSize(new java.awt.Dimension(125, 23));
        boutonLiens.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boutonLiensActionPerformed(evt);
            }
        });

        nbLiensCheck.setText("Nombre d'éléments");
        nbLiensCheck.setEnabled(false);
        nbLiensCheck.setFocusable(false);
        nbLiensCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nbLiensCheckActionPerformed(evt);
            }
        });

        listeLiensCheck.setText("Liste d'éléments");
        listeLiensCheck.setEnabled(false);
        listeLiensCheck.setFocusable(false);
        listeLiensCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listeLiensCheckActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout liensPanelLayout = new javax.swing.GroupLayout(liensPanel);
        liensPanel.setLayout(liensPanelLayout);
        liensPanelLayout.setHorizontalGroup(
            liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(liensPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, liensPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(boutonLiens, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(liensPanelLayout.createSequentialGroup()
                        .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(nbLiensCheck)
                                .addGroup(liensPanelLayout.createSequentialGroup()
                                    .addComponent(deparCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(deparColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(liensPanelLayout.createSequentialGroup()
                                    .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(autoCheck, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(natioCheck, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(natioColor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(autoColor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(listeLiensCheck))
                        .addGap(0, 3, Short.MAX_VALUE)))
                .addContainerGap())
        );
        liensPanelLayout.setVerticalGroup(
            liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(liensPanelLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(boutonLiens, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nbLiensCheck)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(listeLiensCheck)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(autoCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(autoColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(natioCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(natioColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(liensPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(deparCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deparColor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        noeudsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Villes", "Restaurants", "Centres de loisirs"
            }
        ));
        noeudsTable.setFocusable(false);
        jScrollPane1.setViewportView(noeudsTable);

        noeudListeLabel.setText("Liste des noeuds :");
        noeudListeLabel.setEnabled(false);

        liensTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Autoroutes", "Nationales", "Départementales"
            }
        ));
        liensTable.setFocusable(false);
        jScrollPane2.setViewportView(liensTable);

        lienListeLabel.setText("Liste des liens :");
        lienListeLabel.setEnabled(false);

        selectionFichier.setText("Sélectionner un fichier");
        selectionFichier.setFocusable(false);
        selectionFichier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectionFichierActionPerformed(evt);
            }
        });

        noeudSelectLabel.setText("Premier noeud sélectionné:");
        noeudSelectLabel.setEnabled(false);

        lienSelectLabel.setText("Lien sélectionné:");
        lienSelectLabel.setEnabled(false);

        lienSelectCOMBOX.setEnabled(false);
        lienSelectCOMBOX.setFocusable(false);
        lienSelectCOMBOX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lienSelectCOMBOXActionPerformed(evt);
            }
        });

        villesVoisLabel.setText(" ");

        restauVoisLabel.setText(" ");

        loisirVoisLabel.setText(" ");

        lienDescLabel.setText("  ");

        lienDescLabel2.setText("  ");

        lienDescLabel3.setText("  ");

        distanceLabel.setText("Pas assez de noeuds sélectionnés !");
        distanceLabel.setEnabled(false);

        loisirVoisLabel2.setText(" ");

        restauVoisLabel2.setText(" ");

        villesVoisLabel2.setText(" ");

        noeudSelect2Label.setText("Deuxième noeud sélectionné:");
        noeudSelect2Label.setEnabled(false);

        culturelleLabel.setText("  ");

        gastronomiqueLabel.setText("  ");

        ouverteLabel.setText("  ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(selectionFichier)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(boutonReset, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(ouverteLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(gastronomiqueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(culturelleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(noeudsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(liensPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(villesVoisLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(restauVoisLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(loisirVoisLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(noeudSelectLabel)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(noeudListeLabel)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(lienDescLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lienDescLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lienDescLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(noeudSelect2Label)
                    .addComponent(distanceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(villesVoisLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(restauVoisLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(loisirVoisLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(lienSelectLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(lienSelectCOMBOX, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addGap(12, 12, 12)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(lienListeLabel)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectionFichier)
                    .addComponent(boutonReset))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(liensPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 201, Short.MAX_VALUE)
                    .addComponent(noeudsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(noeudListeLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lienListeLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(noeudSelectLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(villesVoisLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(restauVoisLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loisirVoisLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(noeudSelect2Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(villesVoisLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(restauVoisLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loisirVoisLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lienSelectLabel)
                    .addComponent(lienSelectCOMBOX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lienDescLabel)
                .addGap(0, 0, 0)
                .addComponent(lienDescLabel2)
                .addGap(0, 0, 0)
                .addComponent(lienDescLabel3)
                .addGap(18, 18, 18)
                .addComponent(distanceLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ouverteLabel)
                .addGap(0, 0, 0)
                .addComponent(gastronomiqueLabel)
                .addGap(0, 0, 0)
                .addComponent(culturelleLabel)
                .addGap(307, 307, 307))
        );

        getContentPane().add(jPanel3, java.awt.BorderLayout.LINE_END);

        jPanel2.setPreferredSize(new java.awt.Dimension(1400, 1000));

        pageDessin.setPreferredSize(new java.awt.Dimension(1400, 1000));
        pageDessin.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                pageDessinMouseDragged(evt);
            }
        });
        pageDessin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pageDessinMouseClicked(evt);
            }
        });
        pageDessin.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1400, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(pageDessin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(pageDessin, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Lorsque l'utilisateur clique sur le bouton "Afficher les noeuds"/"Masquer les noeuds"
     * @param evt Correspond à l'évènement reçu
     */
    private void boutonNoeudsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boutonNoeudsActionPerformed
        if (pageDessin.getNoeudsDejaPlaces() == false){
            pageDessin.defCoordNoeuds(docCsv.getListeNoeudsDistinct());
            pageDessin.addNoeuds();
        }
        
        else{
            pageDessin.cacheNoeuds();
        }
        
        if (boutonNoeuds.getText().equals("Masquer les noeuds") && modif == false){

            
            if(boutonLiens.getText().equals("Afficher les liens")){
                 boutonReset.setEnabled(false);
            }
            boutonNoeuds.setText("Afficher les noeuds");
            
            villeCheck.setEnabled(false);
            restauCheck.setEnabled(false);
            loisirCheck.setEnabled(false);
            nbNoeudsCheck.setEnabled(false);
            listeNoeudsCheck.setEnabled(false);
            noeudSelectLabel.setEnabled(false);
            noeudSelect2Label.setEnabled(false);
        }
        
      else{
            boutonNoeuds.setText("Masquer les noeuds");
            villeCheck.setEnabled(true);
            restauCheck.setEnabled(true);
            loisirCheck.setEnabled(true);
            nbNoeudsCheck.setEnabled(true);
            listeNoeudsCheck.setEnabled(true);
            noeudSelectLabel.setEnabled(true);
            noeudSelect2Label.setEnabled(true);
            
            villeCheck.setSelected(true);
            restauCheck.setSelected(true);
            loisirCheck.setSelected(true);
            
            boutonReset.setEnabled(true);
            
            modif = false;
        }
    }//GEN-LAST:event_boutonNoeudsActionPerformed

    /**
     * Lorsque l'utilisateur clique sur le bouton "Changer la disposition"
     * @param evt Correspond à l'évènement reçu
     */
    private void boutonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boutonResetActionPerformed
        villeCheck.setSelected(true);
        restauCheck.setSelected(true);
        loisirCheck.setSelected(true);
        autoCheck.setSelected(true);
        deparCheck.setSelected(true);
        natioCheck.setSelected(true);
        pageDessin.effacer();
        
        if(boutonNoeuds.getText().equals("Masquer les noeuds")){
            modif = true;
            this.boutonNoeudsActionPerformed(evt);
        }
        
        if(boutonLiens.getText().equals("Masquer les liens")){
            modif = true;
            this.boutonLiensActionPerformed(evt);
        }
    }//GEN-LAST:event_boutonResetActionPerformed

    /**
     * Lorsque l'utilisateur clique sur le bouton "Afficher les liens"/"Masquer les liens"
     * @param evt Correspond à l'évènement reçu
     */
    private void boutonLiensActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boutonLiensActionPerformed
        if (pageDessin.getLiensImportes() == false){
            pageDessin.addLiens(docCsv.getListeLiensDistinct(), docCsv.getListeNoeudsDistinct());
        }
        else{
            pageDessin.cacheLiens();
        }
        
        if (boutonLiens.getText().equals("Masquer les liens") && modif == false ){
            
          if(boutonNoeuds.getText().equals("Afficher les noeuds")){
                 boutonReset.setEnabled(false);
            }
            boutonLiens.setText("Afficher les liens");
            autoCheck.setEnabled(false);
            natioCheck.setEnabled(false);
            deparCheck.setEnabled(false);
            nbLiensCheck.setEnabled(false);
            listeLiensCheck.setEnabled(false);
        }
      else{
            boutonLiens.setText("Masquer les liens");
            boutonReset.setEnabled(true);
            autoCheck.setEnabled(true);
            natioCheck.setEnabled(true);
            deparCheck.setEnabled(true);
            nbLiensCheck.setEnabled(true);
            listeLiensCheck.setEnabled(true);
            autoCheck.setSelected(true);
            natioCheck.setSelected(true);
            deparCheck.setSelected(true);
            modif = false;
        }
    }//GEN-LAST:event_boutonLiensActionPerformed
   
    /**
     * Lorsque l'utilisateur coche/décoche la case "Villes"
     * @param evt Correspond à l'évènement reçu
     */
    private void villeCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_villeCheckActionPerformed
        pageDessin.repaint();
    }//GEN-LAST:event_villeCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur coche/décoche la case "Restaurants"
     * @param evt Correspond à l'évènement reçu
     */
    private void restauCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restauCheckActionPerformed
        pageDessin.repaint();
    }//GEN-LAST:event_restauCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur coche/décoche la case "Centres de loisirs"
     * @param evt Correspond à l'évènement reçu
     */
    private void loisirCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loisirCheckActionPerformed
        pageDessin.repaint();
    }//GEN-LAST:event_loisirCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur coche/décoche la case "Nationales"
     * @param evt Correspond à l'évènement reçu
     */
    private void natioCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_natioCheckActionPerformed
        pageDessin.repaint();
    }//GEN-LAST:event_natioCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur coche/décoche la case "Départementales"
     * @param evt Correspond à l'évènement reçu
     */
    private void deparCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deparCheckActionPerformed
        pageDessin.repaint();
    }//GEN-LAST:event_deparCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur coche/décoche la case "Autoroutes"
     * @param evt Correspond à l'évènement reçu
     */
    private void autoCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autoCheckActionPerformed
        pageDessin.repaint();
    }//GEN-LAST:event_autoCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur clique sur le panel correspondant à la couleur des villes
     * @param evt Correspond à l'évènement reçu
     */
    private void villeColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_villeColorMouseClicked
        panelSetColor(colorPick.showDialog(this, "Choix de la couleur", colorChoosen), villeColor);
    }//GEN-LAST:event_villeColorMouseClicked
   
    /**
     * Lorsque l'utilisateur clique sur le panel correspondant à la couleur des restaurants
     * @param evt Correspond à l'évènement reçu
     */
    private void restauColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_restauColorMouseClicked
        panelSetColor(colorPick.showDialog(this, "Choix de la couleur", colorChoosen), restauColor);
    }//GEN-LAST:event_restauColorMouseClicked
   
    /**
     * Lorsque l'utilisateur clique sur le panel correspondant à la couleur des centres de loisirs
     * @param evt Correspond à l'évènement reçu
     */
    private void loisirColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loisirColorMouseClicked
       panelSetColor(colorPick.showDialog(this, "Choix de la couleur", colorChoosen), loisirColor);
    }//GEN-LAST:event_loisirColorMouseClicked
   
    /**
     * Lorsque l'utilisateur clique sur le panel correspondant à la couleur des autoroutes
     * @param evt Correspond à l'évènement reçu
     */
    private void autoColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_autoColorMouseClicked
       panelSetColor(colorPick.showDialog(this, "Choix de la couleur", colorChoosen), autoColor);
    }//GEN-LAST:event_autoColorMouseClicked
   
    /**
     * Lorsque l'utilisateur clique sur le panel correspondant à la couleur des départementales
     * @param evt Correspond à l'évènement reçu
     */
    private void natioColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_natioColorMouseClicked
       panelSetColor(colorPick.showDialog(this, "Choix de la couleur", colorChoosen), natioColor);
    }//GEN-LAST:event_natioColorMouseClicked
   
    /**
     * Lorsque l'utilisateur clique sur le panel correspondant à la couleur des nationales
     * @param evt Correspond à l'évènement reçu
     */
    private void deparColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deparColorMouseClicked
       panelSetColor(colorPick.showDialog(this, "Choix de la couleur", colorChoosen), deparColor);
    }//GEN-LAST:event_deparColorMouseClicked
   
    /**
     * Lorsque l'utilisateur  coche/décoche la case "Nombre d'éléments" du panel "Noeuds"
     * @param evt Correspond à l'évènement reçu
     */
    private void nbNoeudsCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nbNoeudsCheckActionPerformed
       if(nbNoeudsCheck.isSelected()){
           
           int nbVille=0, nbRestau=0, nbLoisir=0;
           for(Noeud noeud:docCsv.getListeNoeudsDistinct()){
               
               if(noeud.getTypeNoeud().equals("V")){
                   
                   nbVille++;
               }
               
               else if(noeud.getTypeNoeud().equals("R")){
                   nbRestau++;
               }
               
               else{
                   nbLoisir++;
               }
           }
           villeCheck.setText("Villes (" + nbVille + ")");
           restauCheck.setText("Restaurants (" + nbRestau + ")");
           loisirCheck.setText("Centres de loisirs (" + nbLoisir + ")");
      }
     else{
           villeCheck.setText("Villes");
           restauCheck.setText("Restaurants");
           loisirCheck.setText("Centres de loisirs");
       }
       
    }//GEN-LAST:event_nbNoeudsCheckActionPerformed
   
    /**
     * Lorsque l'utilisateur  coche/décoche la case "Nombre d'éléments" du panel "Liens"
     * @param evt Correspond à l'évènement reçu
     */
    private void nbLiensCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nbLiensCheckActionPerformed
       if(nbLiensCheck.isSelected()){
           
           int nbAuto=0, nbNatio=0, nbDepar=0;
           for(Lien lien:docCsv.getListeLiensDistinct()){
               
               if(lien.getTypeLien().equals(" A")){
                   nbAuto++;
               }
               
               else if(lien.getTypeLien().equals(" N")){
                   nbNatio++;
               }
               
               else{
                   nbDepar++;
               }
           }
           autoCheck.setText("Autoroutes (" + nbAuto + ")");
           natioCheck.setText("Nationales (" + nbNatio + ")");
           deparCheck.setText("Départementales (" + nbDepar + ")");
       }
    else{
           autoCheck.setText("Autoroutes");
           natioCheck.setText("Nationales");
           deparCheck.setText("Départementales");
       }
    }//GEN-LAST:event_nbLiensCheckActionPerformed
  
    /**
     * Lorsque l'utilisateur appuie sur le bouton "Sélectionner un fichier"
     * @param evt Correspond à l'évènement reçu
     */
    private void selectionFichierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectionFichierActionPerformed
       try {
           docCsv.creationNoeudsLiens();
           noeudsPanel.setEnabled(true);
           boutonNoeuds.setEnabled(true);
           boutonLiens.setEnabled(true);
           liensPanel.setEnabled(true);
           noeudListeLabel.setEnabled(true);
           lienListeLabel.setEnabled(true);
            lienSelectLabel.setEnabled(true);
            lienSelectCOMBOX.setEnabled(true);
           for(Lien lien: docCsv.getListeLiensDistinct()){
                lienSelectCOMBOX.addItem(lien.getNoeudParent().getNomNoeud().trim() + " <-> " + lien.getNoeudEnfant().getNomNoeud().trim() +" / "  +lien.getTypeLien() + " " + lien.getTailleLien());
           }
           
           
       } catch (FileNotFoundException ex) {
                               System.out.println("Le fichier n'existe pas");
       }
    }//GEN-LAST:event_selectionFichierActionPerformed

    /**
     * Lorsque l'utilisateur  coche/décoche la case "Liste d'éléments" du panel "Liens"
     * @param evt Correspond à l'évènement reçu
     */
    private void listeLiensCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listeLiensCheckActionPerformed
            
        int v = 0, r=0,l=0;
            DefaultTableModel liensTableModel = new javax.swing.table.DefaultTableModel(
                            new Object [][] {},
                            new String [] {
                                "Autoroutes", "Nationales", "Départementales"
                            }
                        );
            liensTable.setModel(liensTableModel);
            int i = 0;
            
        if(listeLiensCheck.isSelected() ){
    
            for(Lien lien:docCsv.getListeLiensDistinct()){
                
                switch (lien.getTypeLien()) {
                    
                    case " A":
                        liensTableModel.addRow(new Object [][] {{null, null, null}});
                        liensTable.setValueAt(lien.getNoeudParent().getNomNoeud().trim() + " - " + lien.getNoeudEnfant().getNomNoeud().trim(), v, 0);
                        v++;
                        break;
                        
                    case " N":
                        liensTableModel.addRow(new Object [][] {{null, null, null}});
                        liensTable.setValueAt(lien.getNoeudParent().getNomNoeud().trim() + " - " + lien.getNoeudEnfant().getNomNoeud().trim(), r, 1);
                        r++;
                        break;
                        
                    case " D":
                        liensTableModel.addRow(new Object [][] {{null, null, null}});
                        liensTable.setValueAt(lien.getNoeudParent().getNomNoeud().trim() + " - " + lien.getNoeudEnfant().getNomNoeud().trim(), l, 2);
                        l++;
                        break;
                        
                    default:
                        break;
                }
            }
            
           for(int j=0; j<liensTable.getRowCount();j++){
                    
                     if(liensTable.getValueAt(j, 0) == null){
                         
                     }
                     
                     else  if(liensTable.getValueAt(j, 0).toString().contains("Ljava.lang.Object;")){
                        liensTable.setValueAt(null, j, 0);
                     }
                }
                
                  for(int j=0; j<liensTable.getRowCount();j++){
                      
                     if(liensTable.getValueAt(j, 2) == null){
                         
                         liensTableModel.removeRow(j);
                         ((DefaultTableModel)liensTable.getModel()).removeRow(j-1);
                     }
                }
        }
        else{
            liensTableModel.setRowCount(0);
            System.out.println("Décoché");
            }
    }//GEN-LAST:event_listeLiensCheckActionPerformed
    
    /**
     * Lorsque l'utilisateur  coche/décoche la case "Liste d'éléments" du panel "Noeuds"
     * @param evt Correspond à l'évènement reçu
     */
    private void listeNoeudsCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listeNoeudsCheckActionPerformed
            int v = 0, r=0,l=0;
            DefaultTableModel noeudsTableModel = new javax.swing.table.DefaultTableModel(
                            new Object [][] {},
                            new String [] {
                                "Villes", "Restaurants", "Centres de loisirs"
                            }
                        );
            noeudsTable.setModel(noeudsTableModel);
            
        if(listeNoeudsCheck.isSelected() ){
            
            for(Noeud noeud:docCsv.getListeNoeudsDistinct()){
                
                switch (noeud.getTypeNoeud()) {
                    
                    case "V":
                        noeudsTableModel.addRow(new Object [][] {{null, null, null}});
                        noeudsTable.setValueAt(noeud.getNomNoeud().trim(), v, 0);
                        v++;
                        break;
                        
                    case "R":
                        noeudsTable.setValueAt(noeud.getNomNoeud().trim(), r, 1);
                        r++;
                        break;
                        
                    case "L":
                        noeudsTable.setValueAt(noeud.getNomNoeud().trim(), l, 2);
                        l++;
                        break;
                        
                    default:
                        break;
                }
            }
        }
        else{
            noeudsTableModel.setRowCount(0);
            }
    }//GEN-LAST:event_listeNoeudsCheckActionPerformed

    /**
     * Lorsque l'utilisateur clique quelque part dans le panneau de dessin
     * @param evt Correspond à l'évènement reçu
     */
    private void pageDessinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pageDessinMouseClicked
        if(boutonNoeuds.isEnabled()){
            distanceLabel.setEnabled(true);
            select = new selectionNoeuds();
            select.mouseClicked(evt);
            noeudSelectLabel.setText("Premier noeud sélectionné: " + noeudSelect.getNomNoeud());
            Noeud autreNoeud;
            String villeVois ="";
            String restauVois ="" ;
            String loisirVois ="";

            if(!noeudSelect.getNomNoeud().equals("") &&!noeudSelect2.getNomNoeud().equals("") ){
                if(noeudSelect.getNomNoeud().equals(noeudSelect2.getNomNoeud())){
                    distanceLabel.setText("Même noeud sélectionné !");
                    ouverteLabel.setText("");
                    gastronomiqueLabel.setText("");
                    culturelleLabel.setText("");
                }
                else{
                    if(calculDistanceNoeuds(noeudSelect,noeudSelect2)){
                        distanceLabel.setText("Les noeuds sont bien à 2-distance !");
                        ArrayList<String> noeudNb1 = nbTypesDistance(noeudSelect);
                        ArrayList<String> noeudNb2 = nbTypesDistance(noeudSelect2);
                        
                        if( Integer.parseInt(noeudNb1.get(0)) > Integer.parseInt(noeudNb2.get(0))){
                            ouverteLabel.setText(noeudSelect.getNomNoeud() + " est plus ouverte que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else if( Integer.parseInt(noeudNb1.get(0)) < Integer.parseInt(noeudNb2.get(0))){
                            ouverteLabel.setText(noeudSelect.getNomNoeud() + " est moins ouverte que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else{
                            ouverteLabel.setText(noeudSelect.getNomNoeud() + " est aussi ouverte que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        
                        if( Integer.parseInt(noeudNb1.get(1)) > Integer.parseInt(noeudNb2.get(1))){
                            gastronomiqueLabel.setText(noeudSelect.getNomNoeud() + " est plus gastronomique que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else if( Integer.parseInt(noeudNb1.get(1)) < Integer.parseInt(noeudNb2.get(1))){
                            gastronomiqueLabel.setText(noeudSelect.getNomNoeud() + " est moins gastronomique que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else{
                            gastronomiqueLabel.setText(noeudSelect.getNomNoeud() + " est aussi gastronomique que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        
                        if( Integer.parseInt(noeudNb1.get(2)) > Integer.parseInt(noeudNb2.get(2))){
                            culturelleLabel.setText(noeudSelect.getNomNoeud() + " est plus culturelle que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else if( Integer.parseInt(noeudNb1.get(2)) < Integer.parseInt(noeudNb2.get(2))){
                            culturelleLabel.setText(noeudSelect.getNomNoeud() + " est moins culturelle que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else{
                            culturelleLabel.setText(noeudSelect.getNomNoeud() + " est aussi culturelle que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        
                    }
                    else{
                        distanceLabel.setText("Les noeuds ne sont pas à 2-distance...");
                        ArrayList<String> noeudNb1 = nbTypesDistance(noeudSelect);
                        ArrayList<String> noeudNb2 = nbTypesDistance(noeudSelect2);
                        
                        if( Integer.parseInt(noeudNb1.get(0)) > Integer.parseInt(noeudNb2.get(0))){
                            ouverteLabel.setText(noeudSelect.getNomNoeud() + " est plus ouverte que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else if( Integer.parseInt(noeudNb1.get(0)) < Integer.parseInt(noeudNb2.get(0))){
                            ouverteLabel.setText(noeudSelect.getNomNoeud() + " est moins ouverte que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else{
                            ouverteLabel.setText(noeudSelect.getNomNoeud() + " est aussi ouverte que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        
                        if( Integer.parseInt(noeudNb1.get(1)) > Integer.parseInt(noeudNb2.get(1))){
                            gastronomiqueLabel.setText(noeudSelect.getNomNoeud() + " est plus gastronomique que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else if( Integer.parseInt(noeudNb1.get(1)) < Integer.parseInt(noeudNb2.get(1))){
                            gastronomiqueLabel.setText(noeudSelect.getNomNoeud() + " est moins gastronomique que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else{
                            gastronomiqueLabel.setText(noeudSelect.getNomNoeud() + " est aussi gastronomique que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        
                        if( Integer.parseInt(noeudNb1.get(2)) > Integer.parseInt(noeudNb2.get(2))){
                            culturelleLabel.setText(noeudSelect.getNomNoeud() + " est plus culturelle que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else if( Integer.parseInt(noeudNb1.get(2)) < Integer.parseInt(noeudNb2.get(2))){
                            culturelleLabel.setText(noeudSelect.getNomNoeud() + " est moins culturelle que " + noeudSelect2.getNomNoeud() + " !");
                        }
                        else{
                            culturelleLabel.setText(noeudSelect.getNomNoeud() + " est aussi culturelle que " + noeudSelect2.getNomNoeud() + " !");
                        }
                    }
                }
            }

            for(int i=0; i<noeudSelect.getLiens().size();i++){
                 if(noeudSelect.getLiens().get(i).getNoeudParent().getNomNoeud().equals(noeudSelect.getNomNoeud())){
                     autreNoeud = noeudSelect.getLiens().get(i).getNoeudEnfant();
                switch (autreNoeud.getTypeNoeud()) {
                    case "V":
                        if(!villeVois.contains(autreNoeud.getNomNoeud())){
                                 villeVois = villeVois +autreNoeud.getNomNoeud() + ", ";
                        }
                        break;
                    case "R":
                        restauVois =  restauVois + autreNoeud.getNomNoeud()+ ", ";
                        break;
                    default:
                        loisirVois = loisirVois + autreNoeud.getNomNoeud()+ ", ";
                        break;
                }
                 }

                 else if(noeudSelect.getLiens().get(i).getNoeudEnfant().getNomNoeud().equals(noeudSelect.getNomNoeud())){
                     autreNoeud = noeudSelect.getLiens().get(i).getNoeudParent();
                switch (autreNoeud.getTypeNoeud()) {
                    case "V":
                        if(!villeVois.contains(autreNoeud.getNomNoeud())){
                            villeVois =  villeVois + autreNoeud.getNomNoeud() + ", ";
                        }
                        break;
                    case "R":
                        restauVois = restauVois + autreNoeud.getNomNoeud()+ ", ";
                        break;
                    default:
                        loisirVois =  loisirVois +autreNoeud.getNomNoeud()+ ", ";
                        break;
                }
                 }

            }

                if(villeVois.contains(",")){
                    villeVois = villeVois.substring(0,villeVois.length() -2);
                }
                else{
                    villeVois = "Aucune";
                }

                 if(restauVois.contains(",")){
                    restauVois = restauVois.substring(0,restauVois.length() -2);
                }
                else{
                    restauVois = "Aucun";
                }

                  if(loisirVois.contains(",")){
                    loisirVois = loisirVois.substring(0,loisirVois.length() -2);
                }
                else{
                    loisirVois = "Aucun";
                }

            if(noeudSelectLabel.isEnabled()){
            villesVoisLabel.setText("Ville(s) voisine(s) : " + villeVois);
            restauVoisLabel.setText("Restaurant(s) voisin(s) : " + restauVois);
            loisirVoisLabel.setText("Centre(s) de loisirs voisin(s) : " + loisirVois);
            }
            
            noeudSelect2Label.setText("Deuxième noeud sélectionné: " + noeudSelect2.getNomNoeud());
            villeVois ="";
            restauVois ="" ;
            loisirVois ="";

            for(int i=0; i<noeudSelect2.getLiens().size();i++){
                 if(noeudSelect2.getLiens().get(i).getNoeudParent().getNomNoeud().equals(noeudSelect2.getNomNoeud())){
                     autreNoeud = noeudSelect2.getLiens().get(i).getNoeudEnfant();
                switch (autreNoeud.getTypeNoeud()) {
                    case "V":
                        if(!villeVois.contains(autreNoeud.getNomNoeud())){
                                 villeVois = villeVois +autreNoeud.getNomNoeud() + ", ";
                        }
                        break;
                    case "R":
                        restauVois =  restauVois + autreNoeud.getNomNoeud()+ ", ";
                        break;
                    default:
                        loisirVois = loisirVois + autreNoeud.getNomNoeud()+ ", ";
                        break;
                }
                 }

                 else if(noeudSelect2.getLiens().get(i).getNoeudEnfant().getNomNoeud().equals(noeudSelect2.getNomNoeud())){
                     autreNoeud = noeudSelect2.getLiens().get(i).getNoeudParent();
                switch (autreNoeud.getTypeNoeud()) {
                    case "V":
                        if(!villeVois.contains(autreNoeud.getNomNoeud())){
                            villeVois =  villeVois + autreNoeud.getNomNoeud() + ", ";
                        }
                        break;
                    case "R":
                        restauVois = restauVois + autreNoeud.getNomNoeud()+ ", ";
                        break;
                    default:
                        loisirVois =  loisirVois +autreNoeud.getNomNoeud()+ ", ";
                        break;
                }
                 }

            }

                if(villeVois.contains(",")){
                    villeVois = villeVois.substring(0,villeVois.length() -2);
                }
                else{
                    villeVois = "Aucune";
                }

                 if(restauVois.contains(",")){
                    restauVois = restauVois.substring(0,restauVois.length() -2);
                }
                else{
                    restauVois = "Aucun";
                }

                  if(loisirVois.contains(",")){
                    loisirVois = loisirVois.substring(0,loisirVois.length() -2);
                }
                else{
                    loisirVois = "Aucun";
                }
                  
            if(noeudSelect2Label.isEnabled()){
            villesVoisLabel2.setText("Ville(s) voisine(s) : " + villeVois);
            restauVoisLabel2.setText("Restaurant(s) voisin(s) : " + restauVois);
            loisirVoisLabel2.setText("Centre(s) de loisirs voisin(s) : " + loisirVois);
            }
            
            pageDessin.repaint();
        }
    }//GEN-LAST:event_pageDessinMouseClicked

    /**
     * Lorsque l'utilisateur sélectionne un élément dans la combo box
     * @param evt Correspond à l'évènement reçu
     */
    private void lienSelectCOMBOXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lienSelectCOMBOXActionPerformed
       String noeudType1 = "";
       String noeudType2 = "";
       String ligne = (String) lienSelectCOMBOX.getSelectedItem();
       String noeud1 = ligne.substring(0, ligne.indexOf(" "));
       String noeud2 = ligne.substring(ligne.indexOf("<->")+3,ligne.indexOf("/")).trim();
       String typeLien = ligne.substring(ligne.indexOf("/")+3,ligne.indexOf("/")+4);
       String tailleLien = ligne.substring(ligne.indexOf("/")+5, ligne.length());

       for(Noeud noeud: docCsv.getListeNoeudsDistinct()){
           if(noeud.getNomNoeud().trim().equals(noeud1)){
               noeudType1 = noeud.getTypeNoeud();
           }
           else if(noeud.getNomNoeud().trim().equals(noeud2)){
               noeudType2 = noeud.getTypeNoeud();
           }
       }
       switch (noeudType1) {
           case "V":
               noeudType1 = "la ville";
               break;
           case "R":
               noeudType1 = "le restaurant";
               break;
           default:
               noeudType1 = "le centre de loisirs";
               break;
       }
       
       switch (noeudType2) {
           case "V":
               noeudType2 = "la ville";
               break;
           case "R":
               noeudType2 = "le restaurant";
               break;
           default:
               noeudType2 = "le centre de loisirs";
               break;
       }
       
       switch (typeLien) {
           case "A":
               typeLien = "autoroute";
               break;
           case "N":
               typeLien = "nationale";
               break;
           default:
               typeLien = "départementale";
               break;
       }

        lienDescLabel.setText("Ce lien relie " + noeudType1 + " " + noeud1 +  " et " );
         lienDescLabel2.setText( noeudType2 + " " + noeud2 +  " via");
         lienDescLabel3.setText("une " + typeLien + " de " + tailleLien + " km.");
    }//GEN-LAST:event_lienSelectCOMBOXActionPerformed

    /**
     * Lorsque l'utilisateur "drag" sa souris dans le dessin, soit cliquer et bouger en même temps.
     * @param evt Correspond à l'évènement reçu
     */
    private void pageDessinMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pageDessinMouseDragged
      if(SwingUtilities.isLeftMouseButton(evt)){
            noeudSelect.setCoordX(evt.getX());
            noeudSelect.setCoordY(evt.getY());
            pageDessin.repaint();
      }
      else if (SwingUtilities.isRightMouseButton(evt)){
            noeudSelect2.setCoordX(evt.getX());
            noeudSelect2.setCoordY(evt.getY());
            pageDessin.repaint();
      }
    }//GEN-LAST:event_pageDessinMouseDragged

   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JCheckBox autoCheck;
    private static javax.swing.JPanel autoColor;
    private javax.swing.JButton boutonLiens;
    private javax.swing.JButton boutonNoeuds;
    private javax.swing.JButton boutonReset;
    private javax.swing.JLabel culturelleLabel;
    private static javax.swing.JCheckBox deparCheck;
    private static javax.swing.JPanel deparColor;
    private javax.swing.JLabel distanceLabel;
    private javax.swing.JLabel gastronomiqueLabel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lienDescLabel;
    private javax.swing.JLabel lienDescLabel2;
    private javax.swing.JLabel lienDescLabel3;
    private javax.swing.JLabel lienListeLabel;
    private javax.swing.JComboBox<String> lienSelectCOMBOX;
    private javax.swing.JLabel lienSelectLabel;
    private javax.swing.JPanel liensPanel;
    private javax.swing.JTable liensTable;
    private javax.swing.JCheckBox listeLiensCheck;
    private javax.swing.JCheckBox listeNoeudsCheck;
    private static javax.swing.JCheckBox loisirCheck;
    private static javax.swing.JPanel loisirColor;
    private javax.swing.JLabel loisirVoisLabel;
    private javax.swing.JLabel loisirVoisLabel2;
    private static javax.swing.JCheckBox natioCheck;
    private static javax.swing.JPanel natioColor;
    private javax.swing.JCheckBox nbLiensCheck;
    private javax.swing.JCheckBox nbNoeudsCheck;
    private javax.swing.JLabel noeudListeLabel;
    private javax.swing.JLabel noeudSelect2Label;
    private javax.swing.JLabel noeudSelectLabel;
    private javax.swing.JPanel noeudsPanel;
    private javax.swing.JTable noeudsTable;
    private javax.swing.JLabel ouverteLabel;
    private static saegraphemap.dessinGraphe pageDessin;
    private static javax.swing.JCheckBox restauCheck;
    private static javax.swing.JPanel restauColor;
    private javax.swing.JLabel restauVoisLabel;
    private javax.swing.JLabel restauVoisLabel2;
    private javax.swing.JButton selectionFichier;
    private static javax.swing.JCheckBox villeCheck;
    private static javax.swing.JPanel villeColor;
    private javax.swing.JLabel villesVoisLabel;
    private javax.swing.JLabel villesVoisLabel2;
    // End of variables declaration//GEN-END:variables
// </editor-fold>
    
    

// <editor-fold defaultstate="collapsed" desc="    MAIN">
    /**
     * Lance le programme
     * @param args Correspond aux éventuels arguments (par défaut, il n'y en a pas)
     */
    public static void main(String args[]) {
        /* Permet de régler nos préférences en terme de Look and Feel (ici, on règle sur Windows)*/
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SaeGRAPHEMAP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SaeGRAPHEMAP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SaeGRAPHEMAP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SaeGRAPHEMAP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
       

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new SaeGRAPHEMAP().setVisible(true);
                } catch (FileNotFoundException ex) {
                    System.out.println("Le fichier n'existe pas");
                }
            }
        });
    }
// </editor-fold>
    
    
    
}
